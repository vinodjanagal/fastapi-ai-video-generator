#!/bin/bash
echo ">>> PHOENIX V25: INITIALIZING..."

# 1. INSTALL DEPENDENCIES
# Core AI + Audio (Edge-TTS) + Video (MoviePy)
pip install -q "protobuf==3.20.3" "moviepy==1.0.3" "imageio[ffmpeg]" edge-tts
pip install -q diffusers transformers accelerate safetensors opencv-python groq soundfile librosa

# 2. RUN DIRECTOR
# Uses the V25 safe audio integration
python3 app/orchestrator/phoenix_director.py --prompt "$1" --mode production
