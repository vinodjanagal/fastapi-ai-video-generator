import os
import argparse
import subprocess
import logging
import uuid
import glob
import asyncio
from pathlib import Path

# --- V25 UPGRADE: IMPORT EXISTING AUDIO ENGINE ---
try:
    from app.audio_generator import generate_audio_from_text
    AUDIO_ENABLED = True
except ImportError:
    AUDIO_ENABLED = False

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("phoenix.v25.safe")

class PhoenixDirector:
    def __init__(self, mode="production"):
        self.root = os.getcwd()
        self.output_dir = os.path.join(self.root, "phoenix_output")
        self.engine_script = os.path.join(self.root, "app", "video_engines", "animate_diff_engine.py")
        
        # V25 Config: High Quality
        self.conf = {
            "char":  {"width": 512, "height": 512, "frames": 16, "steps": 30},
            "scene": {"width": 512, "height": 384, "frames": 16, "steps": 30}
        }
        os.makedirs(self.output_dir, exist_ok=True)

    def run_command(self, cmd):
        logger.info(f"[EXEC] {' '.join(cmd)}")
        try:
            subprocess.run(cmd, check=True)
        except subprocess.CalledProcessError:
            logger.error("Command Failed.")
            raise

    def generate_character(self, prompt, uid):
        logger.info(">>> PHASE 1: IDENTITY")
        out_dir = os.path.join(self.output_dir, f"char_{uid}")
        sheet_prompt = f"full body character sheet, {prompt}, detailed face, neutral expression, flat background, masterpiece"
        cmd = [
            "python", self.engine_script, "--prompt", sheet_prompt,
            "--output-dir", out_dir, "--width", "512", "--height", "512",
            "--num-frames", "16", "--num-steps", "30", "--guidance-scale", "8.0"
        ]
        self.run_command(cmd)

    def generate_scenes(self, identity, uid):
        logger.info(">>> PHASE 2: SCENES + AUDIO (V25 SAFE)")
        scene_dirs = []
        
        # V25 SCRIPT: Added 'narrate' field for Audio
        script = [
            {
                "visual": f"Extreme wide shot, establishing shot, {identity}, cinematic lighting, volumetric fog, 8k",
                "narrate": "In the shadow of the neon spires, the city breathes."
            },
            {
                "visual": f"Medium camera shot, {identity}, looking at camera, intense focus, depth of field, detailed armor",
                "narrate": "One warrior stands between order and chaos."
            },
            {
                "visual": f"Dynamic action shot, low angle, {identity}, running, motion blur, particle effects, dramatic lighting",
                "narrate": "The hunt begins now."
            }
        ]

        for i, beat in enumerate(script):
            logger.info(f"--- SCENE {i+1} ---")
            out_dir = os.path.join(self.output_dir, f"scene_{uid}_{i+1}")
            scene_dirs.append(out_dir)
            
            # 1. VISUALS (Synchronous Subprocess)
            cmd = [
                "python", self.engine_script, "--prompt", beat["visual"],
                "--output-dir", out_dir, "--width", "512", "--height", "384",
                "--num-frames", "16", "--num-steps", "30", "--seed", str(42 + i)
            ]
            self.run_command(cmd)
            
            # 2. AUDIO (Async Wrapper)
            if AUDIO_ENABLED:
                audio_path = os.path.join(out_dir, "narration.wav")
                try:
                    logger.info(f"Generating Audio: {beat['narrate']}")
                    asyncio.run(generate_audio_from_text(beat['narrate'], "narration.wav"))
                    
                    # Move file to correct location if needed
                    generated_src = os.path.join(self.root, "static", "audio", "narration.wav")
                    if os.path.exists(generated_src):
                        import shutil
                        shutil.move(generated_src, audio_path)
                        logger.info("Audio attached.")
                    elif os.path.exists("narration.wav"):
                         import shutil
                         shutil.move("narration.wav", audio_path)
                         logger.info("Audio attached (local fallback).")

                except Exception as e:
                    logger.error(f"Audio Failed: {e}")

        return scene_dirs

    def stitch(self, scene_dirs, uid):
        logger.info(">>> PHASE 3: FINAL CUT")
        try:
            from moviepy.editor import ImageSequenceClip, concatenate_videoclips, AudioFileClip
            clips = []
            for d in scene_dirs:
                frames = sorted(glob.glob(os.path.join(d, "frames", "*.png")))
                if frames: 
                    video = ImageSequenceClip(frames, fps=12)
                    
                    # Attach Audio
                    audio_path = os.path.join(d, "narration.wav")
                    if os.path.exists(audio_path):
                        audio = AudioFileClip(audio_path)
                        if audio.duration > video.duration:
                            video = video.set_duration(audio.duration) # Freeze last frame
                        video = video.set_audio(audio)
                    
                    clips.append(video)
            
            if clips:
                final = concatenate_videoclips(clips, method="compose")
                out = os.path.join(self.output_dir, f"PHOENIX_V25_{uid}.mp4")
                final.write_videofile(out, codec="libx264", audio_codec="aac", verbose=False, logger=None)
                logger.info(f"DONE. FILE: {out}")
        except Exception as e:
            logger.error(f"Stitch Error: {e}")

    def run(self, prompt):
        uid = uuid.uuid4().hex[:6]
        self.generate_character(prompt, uid)
        scene_dirs = self.generate_scenes(prompt, uid)
        self.stitch(scene_dirs, uid)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--prompt", required=True)
    parser.add_argument("--mode", default="production")
    args = parser.parse_args()
    PhoenixDirector(args.mode).run(args.prompt)
